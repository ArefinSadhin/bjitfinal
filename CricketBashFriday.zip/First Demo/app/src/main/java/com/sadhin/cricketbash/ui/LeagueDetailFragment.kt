package com.sadhin.cricketbash.ui

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sadhin.cricketbash.MainActivity
import com.sadhin.cricketbash.R
import com.sadhin.cricketbash.adapter.LeagueAdapter
import com.sadhin.cricketbash.adapter.LeagueDetailAdapter
import com.sadhin.cricketbash.databinding.FragmentLeagueBinding
import com.sadhin.cricketbash.databinding.FragmentLeagueDetailBinding
import com.sadhin.cricketbash.viewmodel.FixtureViewModel


class LeagueDetailFragment : Fragment() {
    private var _binding: FragmentLeagueDetailBinding?=null
    private  val binding get()=_binding!!
    private lateinit var viewModel: FixtureViewModel
    private lateinit var recyclerView: RecyclerView
    private val navArgs:LeagueDetailFragmentArgs by navArgs()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_league_detail, container, false)
        _binding= FragmentLeagueDetailBinding.inflate(inflater,container,false)
        viewModel = ViewModelProvider(requireActivity())[FixtureViewModel::class.java]
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerView=binding.recyclerView
        //recyclerView.layoutManager=LinearLayoutManager(context,LinearLayoutManager.HORIZONTAL,false)
        recyclerView.layoutManager=LinearLayoutManager(context)
        val adapter= LeagueDetailAdapter(requireContext(),viewModel,recyclerView)
        recyclerView.adapter=adapter
        Log.d("league_id", "onViewCreated: ${navArgs.leagueId}")
        viewModel.loadLeagueDetail(navArgs.leagueId,navArgs.seasonId)
        viewModel.leagueFixture.observe(viewLifecycleOwner){
            adapter.set(it)
        }

    }

    companion object {
    }
}