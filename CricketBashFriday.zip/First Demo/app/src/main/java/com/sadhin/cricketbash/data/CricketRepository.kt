package com.sadhin.cricketbash.data
import androidx.lifecycle.LiveData

import com.sadhin.cricketbash.model.fixtureRecent.FixtureRecentList
import java.text.SimpleDateFormat

import java.util.*

class CricketRepository(private val cricketDao: CricketDao) {
    var fixtureRecent:LiveData<List<FixtureRecentList>> = cricketDao.getFixtureRecent(getDate())
    var fixtureUpcoming:LiveData<List<FixtureRecentList>> = cricketDao.getFixtureUpcoming(getDate())

    suspend fun addFixtureRecent(fixture: List<FixtureRecentList>?){ fixture?.let { cricketDao.addFixtureRecent(it) } }
    fun getFixtureId(id:Int):FixtureRecentList{
        return  cricketDao.getFixtureId(id)
    }
    private fun getDate():String{
        val calendar = Calendar.getInstance()
        val currentDate = calendar.time
        val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'", Locale.getDefault())
        return dateFormat.format(currentDate)
    }




}