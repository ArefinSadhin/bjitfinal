package com.sadhin.cricketbash.model.fixtureRecent

data class FixtureRecentRun(
    var fixture_id: Int?,
    var id: Int?,
    var inning: Int?,
    var overs: Double?,
    var pp1: String?,
    var pp2: String?,
    var pp3: String?,
    var resource: String?,
    var score: Int?,
    var team_id: Int?,
    var updated_at: String?,
    var wickets: Int?
)
{
    constructor():this(null,null,null,null,null,null,null,null,null,null,null,null)
}