package com.sadhin.cricketbash.model.fixtureRecent

data class Visitorteam(
    val code: String?,
    val country_id: Int?,
    val id: Int?,
    var image_path: String?,
    var name: String?,
    val national_team: Boolean?,
    val resource: String?,
    val updated_at: String?
)
{
    constructor():this(null,null,null,null,null,null,null,null)
}