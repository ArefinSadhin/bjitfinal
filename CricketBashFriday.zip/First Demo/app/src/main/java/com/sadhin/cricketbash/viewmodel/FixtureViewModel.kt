package com.sadhin.cricketbash.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.bumptech.glide.Glide.init
import com.sadhin.cricketbash.data.CricketDatabase
import com.sadhin.cricketbash.data.CricketRepository
import com.sadhin.cricketbash.model.fix.Batting
import com.sadhin.cricketbash.model.fix.Bowling
import com.sadhin.cricketbash.model.fix.Fix
import com.sadhin.cricketbash.model.fix.Lineup
import com.sadhin.cricketbash.model.fixtureRecent.FixtureRecentList
import com.sadhin.cricketbash.model.league.Data
import com.sadhin.cricketbash.model.league.Season

import com.sadhin.cricketbash.network.CricketApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class FixtureViewModel(application: Application): AndroidViewModel(application) {
    private val repository: CricketRepository
    var fixtureRecent: LiveData<List<FixtureRecentList>>

    var fixtureLineupDetails=MutableLiveData<List<Lineup>?>()

    //league
    var leagueList=MutableLiveData<List<Data>?>()
    var leagueSeasonList=MutableLiveData<List<Season>?>()
    var leagueFixture=MutableLiveData<List<FixtureRecentList>?>()

    //fixturedetails
    val _fixtureBattingLocal = MutableLiveData<List<Batting>>()
    val fixtureBattingLocal get()=_fixtureBattingLocal

    val _fixtureBattingVisitor = MutableLiveData<List<Batting>>()
    var fixtureBattingVisitor =_fixtureBattingVisitor

    val _fixtureBowlingLocal = MutableLiveData<List<Bowling>>()
    var fixtureBowlingLocal =_fixtureBowlingLocal

    val _fixtureBowlingVisitor = MutableLiveData<List<Bowling>>()
    var fixtureBowlingVisitor =_fixtureBowlingVisitor

    val _fixtureId=MutableLiveData<FixtureRecentList>()
    var fixtureId =_fixtureId

    val _lineupLocal=MutableLiveData<List<Lineup>>()
    var lineupLocal =_lineupLocal
    val _lineupVisitor=MutableLiveData<List<Lineup>>()
    var lineupVisitor =_lineupVisitor



    init {
        repository = CricketRepository(CricketDatabase.getDatabase(application).CricketDao())
        fixtureRecentLoad()
        fixtureRecent = repository.fixtureRecent
        Log.d("fixture_recent", "fixtureRecentLoad: ${fixtureRecent.value}")
    }
    fun loadFixtureId(id:Int){
        viewModelScope.launch(Dispatchers.IO) {
            _fixtureId.postValue(repository.getFixtureId(id))
        }
    }

    fun fixtureRecentLoad() {
        viewModelScope.launch(Dispatchers.IO) {
            val time="${getTime(-30)},${getTime(30)}"
            Log.d("time", "fixtureRecentLoad: $time")
            val fixture = CricketApi.retrofitService.getFixtureRecent(time)
            repository.addFixtureRecent(fixture.data)
        }
    }

    fun loadFixtureDetails(fixture_id: Int) {
        viewModelScope.launch (Dispatchers.Default){
            val details = CricketApi.retrofitService.getFixtureId(fixture_id)
            Log.d("batiing", "loadFixtureDetails: details$details")


            val batLocal= mutableListOf<Batting>()
            val batVisitor= mutableListOf<Batting>()
            val local=details.data!!.localteam_id
            for (i in details.data.batting!!){
                if (i.team_id==local){ batLocal.add(i)}
                else{batVisitor.add(i)}
            }
            _fixtureBattingLocal.postValue(batLocal)
            _fixtureBattingVisitor.postValue(batVisitor)

            val bowLocal= mutableListOf<Bowling>()
            val bowVisitor= mutableListOf<Bowling>()
            for (i in details.data.bowling!!){
                if (i.team_id==local){ bowLocal.add(i)}
                else{bowVisitor.add(i)}
            }
            _fixtureBowlingLocal.postValue(bowLocal)
            _fixtureBowlingVisitor.postValue(bowVisitor)

            val lineLocal= mutableListOf<Lineup>()
            val lineVisitor= mutableListOf<Lineup>()
            for (i in details.data.lineup!!){
                if (i.lineup?.team_id ==local){ lineLocal.add(i)}
                else{lineVisitor.add(i)}
            }
            _lineupLocal.postValue(lineLocal)
            _lineupVisitor.postValue(lineVisitor)
        }

    }

    fun loadLeagueList(){
        viewModelScope.launch (Dispatchers.IO){
            val league= CricketApi.retrofitService.getLeagues()
            leagueList.postValue(league.data)
            leagueSeasonList.postValue(league.data!![0].seasons?.sortedByDescending { it.updated_at })
        }
    }
    fun loadLeagueDetail(league_id:Int,season_id:Int){
        viewModelScope.launch (Dispatchers.IO){
            val detail= CricketApi.retrofitService.getLeaguesDetail(league_id,season_id)
            leagueFixture.postValue(detail.data)
        }
    }

    fun loadSeasonList(league_id:Int){
        viewModelScope.launch (Dispatchers.IO){
            Log.d("seasonlist", "loadSeasonList:${league_id} ")
            Log.d("seasonlist", "loadSeasonList:${leagueList.value} ")
            for (i in leagueList.value!!){
                if (i.id==league_id){
                    leagueSeasonList.postValue(i.seasons?.sortedByDescending { it.updated_at })

                } } }
    }
    fun getTime(days:Int):String{
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_MONTH, days)
        val futureDate = calendar.time
        val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return formatter.format(futureDate)
    }
}