package com.sadhin.cricketbash.model.fix

data class Link(
    val active: Boolean?,
    val label: String?,
    val url: String?
)