package com.sadhin.cricketbash.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sadhin.cricketbash.R
import com.sadhin.cricketbash.model.league.Data
import com.sadhin.cricketbash.ui.MyAdapterCallback
import com.sadhin.cricketbash.viewmodel.FixtureViewModel


class LeagueAdapter(private val context: Context, private val viewModel: FixtureViewModel, private val callback: MyAdapterCallback):
    RecyclerView.Adapter<LeagueAdapter.ItemViewHolder>() {

    class ItemViewHolder(view: View): RecyclerView.ViewHolder(view){
        val name: TextView =view.findViewById(R.id.textView_league_name)
        val code: TextView =view.findViewById(R.id.textView_league_code)
        val country: ImageView =view.findViewById(R.id.imageView_lineup_country)
        val league: ImageView =view.findViewById(R.id.imageView_lineup_league)

    }
    private var listOfLeague= emptyList<Data>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val layout= LayoutInflater.from(context).inflate(R.layout.league_list,parent,false)
        return ItemViewHolder(layout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val pos=listOfLeague[position]
        holder.name.text=pos.name
        holder.code.text=pos.code

        Glide.with(holder.itemView.context)
            .load(pos.image_path)
            .placeholder(R.drawable.ic_launcher_foreground)
            .into(holder.league)
        Glide.with(holder.itemView.context)
            .load(pos.country?.image_path)
            .placeholder(R.drawable.ic_launcher_foreground)
            .into(holder.country)

        holder.itemView.setOnClickListener{
            pos.id?.let { it1 ->
                pos.name?.let { it2 -> callback.onItemSelected(it2) }
                viewModel.loadSeasonList(it1)
            }

            /*Log.d("league_id", "onBindViewHolder: ${pos.id}")
            val action= pos.id?.let {
                LeagueFragmentDirections.actionLeagueFragmentToLeagueDetailFragment(
                    pos.id
                )
            }
            if (action != null) { holder.itemView.findNavController().navigate(action) }*/


        }
    }

    override fun getItemCount(): Int { return listOfLeague.size }

    fun setFixture(lineup:List<Data>?){
        if (lineup != null) { listOfLeague=lineup }
        notifyDataSetChanged()
    }
}