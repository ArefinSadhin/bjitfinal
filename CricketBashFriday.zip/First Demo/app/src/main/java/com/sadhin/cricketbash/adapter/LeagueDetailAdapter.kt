package com.sadhin.cricketbash.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sadhin.cricketbash.R
import com.sadhin.cricketbash.model.fixtureRecent.FixtureRecentList
import com.sadhin.cricketbash.viewmodel.FixtureViewModel
import java.text.SimpleDateFormat
import java.util.*
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class LeagueDetailAdapter(private val context: Context, private val viewModel: FixtureViewModel, private val recyclerView: RecyclerView):
    RecyclerView.Adapter<LeagueDetailAdapter.ItemViewHolder>() {

    class ItemViewHolder(view: View): RecyclerView.ViewHolder(view){
        val score:TextView=view.findViewById(R.id.textView_result)
        val localImageView: ImageView =view.findViewById(R.id.imageView_lineup_league)
        val visitorImageView: ImageView =view.findViewById(R.id.imageView_right)
        val localTextView:TextView=view.findViewById(R.id.textView_local_score)
        val visitorTextView:TextView=view.findViewById(R.id.textView_visitor_score)
        val localName:TextView=view.findViewById(R.id.textView_local_name)
        val visitorName:TextView=view.findViewById(R.id.textView_visitor_name)

    }
    private var listOfLeagueDetail= emptyList<FixtureRecentList>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val layout=LayoutInflater.from(context).inflate(R.layout.fixture_list,parent,false)
        return ItemViewHolder(layout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val pos=listOfLeagueDetail[position]

        //if(convert(getDate())!! <= pos.starting_at?.let { convert(it) }) { recyclerView.layoutManager?.scrollToPosition(position) }

        holder.score.text=pos.starting_at
        holder.localName.text= pos.localteam?.name.toString()
        holder.visitorName.text= pos.visitorteam?.name.toString()
        if (pos.runs!!.size==2){
            if (pos.runs!![0].team_id==pos.localteam_id){
                holder.localTextView.text= "${pos.runs!![0].score}/${pos.runs!![0].wickets}(${pos.runs!![0].overs})"
                holder.visitorTextView.text= "${pos.runs!![1].score}/${pos.runs!![1].wickets}(${pos.runs!![1].overs})"
            }
            else{
                holder.visitorTextView.text= "${pos.runs!![0].score}/${pos.runs!![0].wickets}(${pos.runs!![0].overs})"
                holder.localTextView.text= "${pos.runs!![1].score}/${pos.runs!![1].wickets}(${pos.runs!![1].overs})"
            }
        }
        Log.d("adapter", "onBindViewHolder: ${pos.runs}")
        Glide.with(holder.itemView.context)
            .load(pos.localteam?.image_path)
            .placeholder(R.drawable.ic_launcher_foreground)
            .into(holder.localImageView)
        Glide.with(holder.itemView.context)
            .load(pos.visitorteam?.image_path)
            .placeholder(R.drawable.ic_launcher_foreground)
            .into(holder.visitorImageView)

    }

    override fun getItemCount(): Int { return listOfLeagueDetail.size }

    fun set(lineup:List<FixtureRecentList>?){
        if (lineup != null) { listOfLeagueDetail=lineup }

        val date=convert(getDate())
        if (date !=null){
            var temp=0
            for (i in listOfLeagueDetail){
                if(date <= i.starting_at?.let { convert(it) }){
                    recyclerView.layoutManager?.scrollToPosition(temp)
                    break
                }
                temp+=1
            } }

        notifyDataSetChanged()
    }
    private fun getDate():String{
        val calendar = Calendar.getInstance()
        val currentDate = calendar.time
        val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'", Locale.getDefault())
        return dateFormat.format(currentDate)
    }
    private fun convert(s:String): Date? {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'", Locale.US)
        dateFormat.timeZone = TimeZone.getTimeZone("UTC")
        return dateFormat.parse(s)
    }

}