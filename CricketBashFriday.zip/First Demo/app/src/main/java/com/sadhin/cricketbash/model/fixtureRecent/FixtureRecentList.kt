package com.sadhin.cricketbash.model.fixtureRecent

import androidx.room.Entity
import androidx.room.Ignore
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.sadhin.cricketbash.data.Converter
import com.squareup.moshi.Json

@Entity(tableName = "fixture_recent")
data class FixtureRecentList(
    @Ignore
    var draw_noresult: String?,
    @Ignore
    var elected: String?,
    var first_umpire_id: Int?,
    @Ignore
    var follow_on: Boolean?,
    @PrimaryKey
    var id: Int?,
    @Ignore
    var last_period: Any?,
    var league_id: Int?,
    var live: Boolean?,

    @TypeConverters(Converter::class)
    var localteam: Localteam?,
    @Ignore
    var localteam_dl_data: LocalteamDlData?,
    var localteam_id: Int?,
    var man_of_match_id: Int?,
    var man_of_series_id: Int?,
    var note: String?,
    var referee_id: Int?,
    @Ignore
    var resource: String?,
    var round: String?,
    @Ignore
    var rpc_overs: String?,
    @Ignore
    var rpc_target: String?,
    @TypeConverters(Converter::class)
    @field:Json(name = "runs")
    var runs: List<FixtureRecentRun>?,
    var season_id: Int?,
    var second_umpire_id: Int?,
    var stage_id: Int?,
    var starting_at: String?,
    var status: String?,
    @Ignore
    var super_over: Boolean?,
    var toss_won_team_id: Int?,
    @Ignore
    var total_overs_played: Int?,
    var tv_umpire_id: Int?,
    var type: String?,
    var venue_id: Int?,

    @TypeConverters(Converter::class)
    var visitorteam: Visitorteam?,
    @Ignore
    var visitorteam_dl_data: VisitorteamDlData?,
    var visitorteam_id: Int?,
    @Ignore
    var weather_report: List<Any>?,
    var winner_team_id: Int?
)
{
    constructor():this(
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null
        )
}