package com.sadhin.cricketbash.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.sadhin.cricketbash.model.fixtureRecent.FixtureRecentList

//@TypeConverters(Converters::class)
@TypeConverters(Converter::class)
@Database(entities = [FixtureRecentList::class], version = 9, exportSchema = false)
abstract class CricketDatabase: RoomDatabase() {
    abstract fun CricketDao():CricketDao
    companion object{
        @Volatile
        private var INSTANCE:CricketDatabase? = null
        fun getDatabase(context: Context):CricketDatabase{
            return INSTANCE ?: synchronized(this){
                INSTANCE = Room.databaseBuilder(
                    context.applicationContext,
                    CricketDatabase::class.java,
                    "cricket_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE!!
            }
        }
    }
}