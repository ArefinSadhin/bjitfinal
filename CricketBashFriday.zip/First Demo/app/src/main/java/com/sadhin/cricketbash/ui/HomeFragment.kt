package com.sadhin.cricketbash.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.viewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sadhin.cricketbash.MainActivity
import com.sadhin.cricketbash.adapter.FixtureAdapter
import com.sadhin.cricketbash.databinding.FragmentHomeBinding
import com.sadhin.cricketbash.viewmodel.FixtureViewModel


class HomeFragment : Fragment() {
    private var _binding:FragmentHomeBinding?=null
    private  val binding get()=_binding!!
    private val state= RECENT
    private lateinit var recyclerView: RecyclerView
    private lateinit var viewModel: FixtureViewModel
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_home, container, false)
        _binding=FragmentHomeBinding.inflate(inflater,container,false)
        viewModel = ViewModelProvider(requireActivity())[FixtureViewModel::class.java]
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView=binding.recyclerViewFixture
        recyclerView.layoutManager=LinearLayoutManager(context)
        val adapter=FixtureAdapter(requireContext(),viewModel)
        recyclerView.adapter=adapter

        val tabLayout = binding.tabLayout
        tabLayout.addTab(tabLayout.newTab().setText(RECENT))
        tabLayout.addTab(tabLayout.newTab().setText("Live"))
        tabLayout.addTab(tabLayout.newTab().setText("Upcoming"))

        viewModel.fixtureRecent.observe(viewLifecycleOwner){
            adapter.setFixture(it)
        }
    }
    companion object {
        const val RECENT="RECENT"
    }
}