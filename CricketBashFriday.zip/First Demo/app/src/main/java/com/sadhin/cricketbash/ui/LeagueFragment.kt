package com.sadhin.cricketbash.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sadhin.cricketbash.R
import com.sadhin.cricketbash.adapter.LeagueAdapter
import com.sadhin.cricketbash.adapter.LeagueSeasonAdapter
import com.sadhin.cricketbash.databinding.FragmentFixtureDetailsBinding
import com.sadhin.cricketbash.databinding.FragmentHomeBinding
import com.sadhin.cricketbash.databinding.FragmentLeagueBinding
import com.sadhin.cricketbash.viewmodel.FixtureViewModel


class LeagueFragment : Fragment(),MyAdapterCallback{
    private var _binding: FragmentLeagueBinding?=null
    private  val binding get()=_binding!!
    private lateinit var viewModel: FixtureViewModel
    private lateinit var recyclerViewLeague: RecyclerView
    private lateinit var recyclerViewSeason: RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_league, container, false)
        _binding= FragmentLeagueBinding.inflate(inflater,container,false)
        viewModel = ViewModelProvider(requireActivity())[FixtureViewModel::class.java]
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerViewLeague=binding.recyclerViewLeague
        val layoutManager = LinearLayoutManager(context)
        layoutManager.orientation = LinearLayoutManager.HORIZONTAL
        recyclerViewLeague.layoutManager=layoutManager
        val adapter=LeagueAdapter(requireContext(),viewModel,this)
        recyclerViewLeague.adapter=adapter
        viewModel.loadLeagueList()

        viewModel.leagueList.observe(viewLifecycleOwner){
            binding.textViewLeague.text= it!![0].name
            adapter.setFixture(it)
        }

        recyclerViewSeason=binding.recyclerViewSeason
        recyclerViewSeason.layoutManager=LinearLayoutManager(context)
        val adapterSeason=LeagueSeasonAdapter(requireContext(),viewModel)
        recyclerViewSeason.adapter=adapterSeason

        viewModel.leagueSeasonList.observe(viewLifecycleOwner){
            adapterSeason.set(it)
        }

    }
    override fun onItemSelected(name: String) {
        binding.textViewLeague.text = name
    }
    companion object {}
}
interface MyAdapterCallback {
    fun onItemSelected(name: String)
}