package com.sadhin.cricketbash.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sadhin.cricketbash.R
import com.sadhin.cricketbash.model.fix.Batting
import com.sadhin.cricketbash.model.fix.Lineup
import com.sadhin.cricketbash.viewmodel.FixtureViewModel

class FixtureLineupAdapter(private val context: Context, private val viewModel: FixtureViewModel):
    RecyclerView.Adapter<FixtureLineupAdapter.ItemViewHolder>() {

    class ItemViewHolder(view: View): RecyclerView.ViewHolder(view){
        val image: ImageView =view.findViewById(R.id.imageView_lineup)
        val name: TextView =view.findViewById(R.id.lineup_first_name)
        val nameLast: TextView =view.findViewById(R.id.lineup_last_name)

        val lineupStyle: TextView =view.findViewById(R.id.lineup_style)
        val lineupDetails: TextView =view.findViewById(R.id.lineup_details)

    }
    private var lineup= emptyList<Lineup>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val layout= LayoutInflater.from(context).inflate(R.layout.lineup_list,parent,false)
        return ItemViewHolder(layout)

    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val pos= lineup[position]
        Log.d("batting", "onBindViewHolder: $pos")
        holder.name.text=pos.firstname
        holder.nameLast.text=pos.lastname

        holder.lineupStyle.text= pos.position?.name.toString()
        var temp=""
        if (pos.battingstyle != null){ temp+=pos.battingstyle.toString() }
        if (pos.battingstyle != null){ temp+=",${pos.bowlingstyle}" }
        holder.lineupDetails.text=temp


        Glide.with(holder.itemView.context)
            .load(pos.image_path)
            .placeholder(R.drawable.ic_launcher_foreground)
            .into(holder.image)

    }

    override fun getItemCount(): Int { return lineup.size
    }
    fun setData(f:List<Lineup>?){
        Log.d("batting", "setData: $f")
        if (f != null) { lineup= f }
        notifyDataSetChanged()
    }





}