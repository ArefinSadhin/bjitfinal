package com.sadhin.cricketbash.model.fix

data class Links(
    val first: String?,
    val last: String?,
    val next: String?,
    val prev: Any?
)