package com.sadhin.cricketbash.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sadhin.cricketbash.R
import com.sadhin.cricketbash.model.fix.Bowling
import com.sadhin.cricketbash.viewmodel.FixtureViewModel

class FixtureBowlingAdapter(private val context: Context, private val viewModel: FixtureViewModel):
    RecyclerView.Adapter<FixtureBowlingAdapter.ItemViewHolder>() {

    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView =view.findViewById(R.id.bowler_image)
        val name: TextView = view.findViewById(R.id.bowler_name)
        val over: TextView = view.findViewById(R.id.bowler_over)
        val maiden: TextView = view.findViewById(R.id.bowler_maiden)
        val run: TextView = view.findViewById(R.id.bowler_run)
        val wickets: TextView = view.findViewById(R.id.bowler_wicket)
        val eco: TextView = view.findViewById(R.id.bowler_eco)

    }

    private var bowling = emptyList<Bowling>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val layout = LayoutInflater.from(context).inflate(R.layout.bowling_list, parent, false)
        return ItemViewHolder(layout)

    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val pos = bowling[position]
        Log.d("batting", "onBindViewHolder: $pos")
        holder.name.text= pos.bowler!!.firstname.toString()
        holder.over.text= pos.overs.toString()
        holder.maiden.text=pos.medians.toString()
        holder.wickets.text=pos.wickets.toString()
        holder.run.text=pos.runs.toString()
        holder.eco.text=pos.rate.toString()

        Glide.with(holder.itemView.context)
            .load(pos.bowler.image_path)
            .placeholder(R.drawable.ic_launcher_foreground)
            .into(holder.image)

    }

    override fun getItemCount(): Int {
        return bowling.size
    }

    fun setData(f: List<Bowling>?) {
        Log.d("batting", "setData: $f")
        if (f != null) { bowling = f }
        notifyDataSetChanged()
    }
}
