package com.sadhin.cricketbash.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.navArgs
import com.bumptech.glide.Glide
import com.google.android.material.tabs.TabLayoutMediator
import com.sadhin.cricketbash.R
import com.sadhin.cricketbash.adapter.FixturePagerAdapter
import com.sadhin.cricketbash.databinding.FragmentFixtureDetailsBinding
import com.sadhin.cricketbash.viewmodel.FixtureViewModel


class FixtureDetailsFragment : Fragment() {
    private var _binding: FragmentFixtureDetailsBinding?=null
    private val binding get()= _binding!!
    private val navArgs:FixtureDetailsFragmentArgs by navArgs()

    private lateinit var viewModel: FixtureViewModel
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_fixture_details, container, false)
        _binding=FragmentFixtureDetailsBinding.inflate(inflater,container,false)
        viewModel = ViewModelProvider(requireActivity())[FixtureViewModel::class.java]
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val tabLayout = binding.tabLayout


        val viewPager=binding.fixturePager
        val tabAdapter=FixturePagerAdapter(childFragmentManager,lifecycle)
        viewPager.adapter=tabAdapter
        TabLayoutMediator(tabLayout,viewPager) { tab, position->
            when(position){
                0-> tab.text = "Home "
                else-> tab.text = "Away"

            }
        }.attach()
        /*tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                if (tab != null) {
                    when (tab.position){
                        0-> { }
                        else->{ }
                    } } }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })*/
        viewModel.loadFixtureDetails(navArgs.fixtureId)
        viewModel.loadFixtureId(navArgs.fixtureId)
        viewModel.fixtureId.observe(viewLifecycleOwner){
            binding.textViewLocalName.text= it.localteam?.name.toString()
            binding.textViewVisitorName.text= it.visitorteam?.name.toString()
            if (it.runs!!.size==2){
                if (it.runs!![0].team_id==it.localteam_id){
                    binding.textViewLocalScore.text= "${it.runs!![0].score}/${it.runs!![0].wickets}(${it.runs!![0].overs})"
                    binding.textViewVisitorScore.text= "${it.runs!![1].score}/${it.runs!![1].wickets}(${it.runs!![1].overs})"
                }
                else{
                    binding.textViewVisitorScore.text= "${it.runs!![0].score}/${it.runs!![0].wickets}(${it.runs!![0].overs})"
                    binding.textViewLocalScore.text= "${it.runs!![1].score}/${it.runs!![1].wickets}(${it.runs!![1].overs})"
                }
            }
            binding.textViewResult.text=it.note.toString()
            Glide.with(requireContext())
                .load(it.localteam?.image_path)
                .placeholder(R.drawable.ic_launcher_foreground)
                .into(binding.imageViewLeft)
            Glide.with(requireContext())
                .load(it.visitorteam?.image_path)
                .placeholder(R.drawable.ic_launcher_foreground)
                .into(binding.imageViewRight)
        }
    }

    companion object {}
}