package com.sadhin.cricketbash.model.league

data class League(
    val `data`: List<Data>?
)