package com.sadhin.cricketbash.data

import android.icu.lang.UCharacter.GraphemeClusterBreak.T
import android.util.Log
import androidx.room.TypeConverter
import com.sadhin.cricketbash.model.fixtureRecent.FixtureRecentList
import com.sadhin.cricketbash.model.fixtureRecent.FixtureRecentRun
import com.sadhin.cricketbash.model.fixtureRecent.Localteam
import com.sadhin.cricketbash.model.fixtureRecent.Visitorteam
import kotlin.math.log

class Converter {
    @TypeConverter
    fun recentRunToString(l:List<FixtureRecentRun>?): String {
        l?.let{
            if (l.size==2){
                return "${l[0].team_id?:"0"}:${l[0].score?:"0"}/${l[0].wickets!!}/${l[0].overs?:"0"}," +
                        "${l[1].team_id?:"0"}:${l[1].score?:"0"}/${l[1].wickets?:"0"}/${l[1].overs?:"0"}"
            }
        }
        return "0:0/0/0,0:0/0/0"
    }
    @TypeConverter
    fun stringToRecentRun(s:String):List<FixtureRecentRun>{
        val l: MutableList<FixtureRecentRun> = mutableListOf<FixtureRecentRun>()
        val temp=s.split(",")
        for( i in temp){
            val n=FixtureRecentRun()
            val temp1=i.split(":")
            n.team_id= temp1[0].toIntOrNull()
            val temp2=temp1[1].split("/")
            Log.d("split", "stringToRecentRun: ${temp2} ")
            n.score=temp2[0].toIntOrNull()
            n.wickets=temp2[1].toIntOrNull()
            n.overs=temp2[2].toDoubleOrNull()
            l.add(n)
        }
        return  l
    }
    @TypeConverter
    fun localToString(l:Localteam): String? { return l.image_path+","+l.name }
    @TypeConverter
    fun stringTolocal(s:String): Localteam {
        val l=Localteam()
        val t=s.split(",")
        l.image_path=t[0]
        l.name=t[1]
        return l
    }
    @TypeConverter
    fun visitorToString(l:Visitorteam): String? { return l.image_path+","+l.name }
    @TypeConverter
    fun stringToVisitor(s:String): Visitorteam {
        val l=Visitorteam()
        val t=s.split(",")
        l.image_path=t[0]
        l.name=t[1]
        return l
    }



    /*@TypeConverter
    fun recentRunToString(l:List<FixtureRecentRun>?): String {
        l?.let{ it ->
            if (it.size==1){
                return "${it[0].score}"
            }
        }
        return "0:0,0:0"
    }*/

}